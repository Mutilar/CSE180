/*
 *  BRIAN HUNGERMAN
 *  ROBOTICS, CSE 180
 *  MARCH 5, 2019
 */

#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Bool.h>
#include <tf/transform_datatypes.h>
#include <sensor_msgs/LaserScan.h>

//Move to Variables
float position[] = {1, 2, 5, 6, 0, 7};
int nPositions = 3;

int indexPosition = 0; 

float ACCURACY_THRESHOLD = .4;

float DISTANCE;

geometry_msgs::Vector3 pos;

//Publisher for /posedrift
ros::Publisher pubTour;

int has_been_sent = 0;

//On Receiving Tour Point
void isAtReceived(const std_msgs::Bool &val)
{

	if (val.data == true){
		
		if (has_been_sent == 0) {
			ROS_INFO_STREAM("TARGET POSITION REACHED(" << pos.x << ", " << pos.y << ")");
			indexPosition++;
			indexPosition %= nPositions;
			has_been_sent = 2;
		}
		else has_been_sent--;
	}

	pos.x = position[indexPosition * 2];
	pos.y = position[(indexPosition * 2) +1];

}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "toury");
	ros::NodeHandle nh;

	//Initialize Subscriptions
	ros::Subscriber subIsAtPoint = nh.subscribe("/is_at_point", 1000, &isAtReceived);	

	//Initialize Publisher
	pubTour = nh.advertise<geometry_msgs::Vector3>("/tour", 1000);	

	pos.x = position[indexPosition * 2];
	pos.y = position[(indexPosition * 2) +1];

	//Listen to Subscription, Publish Target Position
	while (nh.ok()) {


		ros::Duration(.5).sleep();	
		if (has_been_sent == 0) has_been_sent = 2;	
		pubTour.publish(pos);
		ros::Duration(.5).sleep();	
		ros::spinOnce();
	}
}
