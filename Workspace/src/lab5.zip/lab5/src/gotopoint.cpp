/*
 *  BRIAN HUNGERMAN
 *  ROBOTICS, CSE 180
 *  MARCH 5, 2019
 */

#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Bool.h>
#include <tf/transform_datatypes.h>
#include <sensor_msgs/LaserScan.h>

//Move to Variables
float X = 5;
float Y = 5;
float THETA = -3.1415/2;

float ACCURACY_THRESHOLD = .4;

float DISTANCE;

//Store local copies of most recent poses
geometry_msgs::Pose basePos;
//Store copy of command
geometry_msgs::Twist msg;
std_msgs::Bool is_at_position_flag;

//Publisher for /posedrift
ros::Publisher pubVel;
ros::Publisher pubTour;

float dist_to_closest_obs;

bool isBackingUp;
bool isRotatingToRandom;
bool isMovingToRandom;

//On Receiving Pose Ground Truth reading
void rangeReceived(const sensor_msgs::LaserScan &msg)
{
	// ROS_INFO_STREAM("SIZE(" << msg.ranges.size() << ")");
	dist_to_closest_obs = msg.ranges[0];
	for (int i = 720 / 4; i < msg.ranges.size() - (720/4); i++) {
		if (dist_to_closest_obs > msg.ranges[i]) {
			dist_to_closest_obs = msg.ranges[i];
		}
	}
	
	if (dist_to_closest_obs < .6) {
		isBackingUp = true;
		isRotatingToRandom = true;
		isMovingToRandom = true;
		THETA = ((rand() % 100) / 100.0 * 2 * 3.1415) - 3.1415;
		DISTANCE = (rand() % 3) + 2;
		ROS_INFO_STREAM("TOO CLOSE TO OBJECT(" << dist_to_closest_obs << ")");
	}

}

//On Receiving Tour Point
void tourReceived(const geometry_msgs::Vector3 &pos)
{
	ROS_INFO_STREAM("TARGET POSITION SET TO(" << pos.x << ", " << pos.y << ")");
	X = pos.x;
	Y = pos.y;
}

//On Receiving Pose Ground Truth reading
void positionReceived(const nav_msgs::Odometry &pos)
{
	//Update local copy of Pose Ground Truth
	basePos = pos.pose.pose;
	double roll,pitch,yaw;

	//From answers.ros.org [convert the yaw Euler angle into the range...]
	tf::Quaternion q(basePos.orientation.x, basePos.orientation.y, basePos.orientation.z, basePos.orientation.w);
	tf::Matrix3x3 m(q);
	m.getRPY(roll, pitch, yaw);

	is_at_position_flag.data = false;

	//ROS_INFO_STREAM(yaw);
	if (ros::ok())
	{
		//BACKING UP
		if (isBackingUp ) {
			if (DISTANCE > 0) {
				msg.linear.x = -.5;
				msg.angular.z = 0;
				DISTANCE -= .1;
				ROS_INFO_STREAM("BACKING UP FOR(" << DISTANCE << ")");
			} else {
				isBackingUp = false;
				msg.linear.x = 0;
				msg.angular.z = 0;
				DISTANCE = (rand() % 10) + 4;
			}
		}
		//ROTATING TO RANDOM
		else if (isRotatingToRandom) {
			double difference_in_angles = yaw - THETA;
			if (difference_in_angles < 0) difference_in_angles = -difference_in_angles;
			if (difference_in_angles < ACCURACY_THRESHOLD * 2) {
				isRotatingToRandom = false;
				msg.linear.x = 0;
				msg.angular.z = 0;
			}
			else {
				ROS_INFO_STREAM("ROTATING TOWARDS THETA(" << THETA << ")");
				msg.linear.x = 0;
				msg.angular.z = 1;
					
			}
		}
		else if (isMovingToRandom) {
			if (DISTANCE > 0) {
				msg.linear.x = .75;
				msg.angular.z = 0;
				DISTANCE -= .075;
				ROS_INFO_STREAM("MOVING FOR(" << DISTANCE << ")");
			} else {
				isMovingToRandom = false;
				msg.linear.x = 0;
				msg.angular.z = 0;
			}
		}
		//Regular movement
		else {
			float x_base = basePos.position.x, y_base = basePos.position.y;
			double distance_to_target = sqrt(((x_base - X) * (x_base - X)) + ((y_base - Y) * (y_base - Y)));
		
			if (distance_to_target < ACCURACY_THRESHOLD) {
				msg.linear.x = 0;
				msg.angular.z = 0;
				ROS_INFO_STREAM("WENT TO POSITION(" << X << "," << Y << ")!");
				is_at_position_flag.data = true;
				pubTour.publish(is_at_position_flag);

			}
			else {
				//Find angle towards target X,Y from current X,Y
				double angle = atan2(Y - y_base, X - x_base);
			
				//Rotate to Theta
				msg.angular.z = .4;
				double difference_in_angles = yaw - angle;
				if (difference_in_angles < 0) difference_in_angles = -difference_in_angles;
				//If within threshold to theta, move forward
				if (difference_in_angles < ACCURACY_THRESHOLD) {
					ROS_INFO_STREAM("MOVING TOWARDS POSITION(" << X << "," << Y << ")");
				//move forward
					msg.linear.x = .5;
					msg.angular.z = 0;
				}
				else {
					ROS_INFO_STREAM("ROTATING TOWARDS POSITION(" << X << "," << Y << ")");
					msg.linear.x = 0;
				}
			}
		}
		pubVel.publish(msg);
	}
	
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "gotoey");
	ros::NodeHandle nh;
	//Initialize Subscriptions
	ros::Subscriber subPosition = nh.subscribe("/odometry/filtered", 1000, &positionReceived);
	ros::Subscriber subRange = nh.subscribe("/scan", 1000, &rangeReceived);	
	ros::Subscriber subTour = nh.subscribe("/tour", 1000, &tourReceived);	
	
	//Initialize Publisher
	pubVel = nh.advertise<geometry_msgs::Twist>("/husky_velocity_controller/cmd_vel", 1000);
	pubTour = nh.advertise<std_msgs::Bool>("/is_at_point", 1000);	
	//Listen to Subscription
	ros::spin();
}
