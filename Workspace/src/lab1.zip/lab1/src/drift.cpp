#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float64.h>

geometry_msgs::Pose odomPos;
geometry_msgs::Pose basePos;
std_msgs::Float64 val;
ros::Publisher pubDist;
double dist; 

void odomReceived(const nav_msgs::Odometry &msg) {
  odomPos = msg.pose.pose;
  if (ros::ok()) {
	  //calculate distance betwee real and theoretical XY positions
          double x1 = odomPos.position.x, x2 = basePos.position.x, y1 = odomPos.position.y, y2 = basePos.position.y;
	  val.data = sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1))); 
	  pubDist.publish(val);  	
  }
}
void baseReceived(const nav_msgs::Odometry &msg) {
  basePos = msg.pose.pose;
}

int main (int argc, char** argv)
{
	ros::init(argc, argv, "listener");
	ros::NodeHandle  nh;

	ros::Subscriber subOdom = nh.subscribe("/pioneer/odom", 1000, &odomReceived);
	ros::Subscriber subActual = nh.subscribe("/base_pose_ground_truth", 1000, &baseReceived);

	pubDist = nh.advertise<std_msgs::Float64>("/posedrift", 1000);

	ros::spin();
}
