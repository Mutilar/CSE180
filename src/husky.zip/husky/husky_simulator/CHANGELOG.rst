^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package husky_simulator
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2018-08-02)
------------------

0.3.0 (2018-04-11)
------------------
* Fixed typo in URLs.
* Remove defunct email address
* Updated maintainers.
* Move packages into monorepo for kinetic; strip out ur packages
* Contributors: Paul Bovbel, Tony Baltovski

0.2.6 (2016-10-26)
------------------

0.2.5 (2015-12-31)
------------------

0.2.4 (2015-07-08)
------------------

0.2.3 (2015-04-13)
------------------

0.2.2 (2015-04-08)
------------------

0.2.1 (2015-03-23)
------------------

0.2.0 (2015-03-23)
------------------

0.1.4 (2015-02-11)
------------------

0.1.3 (2015-02-06)
------------------

0.1.2 (2015-01-30)
------------------
* Update authors
* Contributors: Paul Bovbel

0.1.1 (2015-01-14)
------------------
* Contributors: Paul Bovbel

0.1.0 (2015-01-13)
------------------
* Removed husky_gazebo_plugins in favor of ros_control
* Contributors: Paul Bovbel

0.0.3 (2013-11-01)
------------------

0.0.2 (2013-09-30)
------------------

0.0.1 (2013-09-29)
------------------
* Add husky_simulator metapackage.
