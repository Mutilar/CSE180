^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package husky_desktop
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2018-08-02)
------------------

0.3.0 (2018-04-11)
------------------
* Updated all package versions to 0.2.6.
* Fixed typo in URLs.
* Remove defunct email address
* Updated maintainers.
* Move packages into monorepo for kinetic; strip out ur packages
* Contributors: Paul Bovbel, Tony Baltovski

0.2.2 (2015-04-08)
------------------

0.2.1 (2015-03-23)
------------------
* Fix package urls
* Contributors: Paul Bovbel

0.2.0 (2015-03-23)
------------------


0.1.1 (2015-02-20)
------------------
* Update description and docs
* Contributors: Paul Bovbel

0.1.0 (2015-01-15)
------------------
* Update descriptions, dependencies, and maintainer
* Add common message dependencies to desktop metapackage.
* Contributors: Mike Purvis, Paul Bovbel

0.0.3 (2013-10-04)
------------------
* Set minimum versions of desktop packages.

0.0.2 (2013-09-29)
------------------
* Add husky_simulator to the desktop package.

0.0.1 (2013-09-16)
------------------
* Metapackages for robot and desktop variants.
