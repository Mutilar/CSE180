^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package husky_robot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2018-08-02)
------------------

0.3.0 (2018-04-11)
------------------
* Remove defunct email address
* Updated maintainers.
* Move packages into monorepo for kinetic; strip out ur packages
* Contributors: Paul Bovbel, Tony Baltovski

0.2.6 (2016-10-03)
------------------
* Adding support for the UM7 IMU.
* Contributors: Tony Baltovski

0.2.5 (2015-12-31)
------------------

0.2.4 (2015-07-08)
------------------

0.2.3 (2015-04-08)
------------------

0.2.2 (2015-03-23)
------------------
* Fix package urls
* Contributors: Paul Bovbel

0.2.1 (2015-03-23)
------------------

0.2.0 (2015-03-23)
------------------

0.1.1 (2015-02-20)
------------------
* Remove navigation
* Update description and docs
* Contributors: Paul Bovbel

0.1.0 (2015-01-15)
------------------
* Update descriptions, dependencies, and maintainer
* Contributors: Paul Bovbel

* RP-264 Update descriptions, dependencies, and maintainer
* Contributors: Paul Bovbel

0.0.3 (2013-10-04)
------------------
* Set minimum version for husky_bringup, add husky_navigation.

0.0.2 (2013-09-29)
------------------
* No change.

0.0.1 (2013-09-16)
------------------
* Metapackages for robot and desktop variants.
