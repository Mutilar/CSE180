/*
 *  BRIAN HUNGERMAN
 *  ROBOTICS, CSE 180
 *  MARCH 22, 2019
 */

#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/PoseStamped.h>

#include <tf/transform_datatypes.h>

#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Bool.h>

double target_rotation;
double target_x, target_y;

bool is_first_run = true;

void amclGetPose(const geometry_msgs::PoseWithCovarianceStamped &amcl_position)
{
	target_x = amcl_position.pose.pose.position.x;
	target_y = amcl_position.pose.pose.position.y;

	double roll, pitch, yaw;

	tf::Quaternion q(amcl_position.pose.pose.orientation.x, amcl_position.pose.pose.orientation.y, amcl_position.pose.pose.orientation.z, amcl_position.pose.pose.orientation.w);
	tf::Matrix3x3 m(q);
	m.getRPY(roll, pitch, yaw);

	target_rotation = yaw;

	ROS_INFO_STREAM("AMCL POSITION(T = " << target_rotation << ", X = " << target_x << ", Y = " << target_y << ")\n");
	is_first_run = false;
}

void getCloud(const geometry_msgs::PoseArray &points)
{
	double total_theta = 0, total_x = 0, total_y = 0, count = 0;

	double roll, pitch, yaw;

	int i = 0;

	/* Summing Point Cloud points*/
	while (i < 500)
	{
		tf::Quaternion q(points.poses[i].orientation.x, points.poses[i].orientation.y, points.poses[i].orientation.z, points.poses[i].orientation.w);
		tf::Matrix3x3 m(q);
		m.getRPY(roll, pitch, yaw);

		total_theta += yaw;
		total_x += points.poses[i].position.x;
		total_y += points.poses[i].position.y;
		i++;
	}
	ROS_INFO_STREAM("AVERAGED POINT CLOUD(T = " << total_theta / i << ", X = " << total_x / i << ", Y = " << total_y / i << ")\n");

	/* Calculate Difference in Point Cloud && AMCL Pose */
	if (!is_first_run)
	{
		ROS_INFO_STREAM("DIFFERENCE(T, " << target_rotation - total_theta / i << ")");
		ROS_INFO_STREAM("DIFFERENCE(X, " << target_x - total_x / i  << ")");
		ROS_INFO_STREAM("DIFFERENCE(Y, " << target_y - total_y / i << ")");
	}
	else
	{
		ROS_INFO_STREAM("WAITING TO RECEIVE AMCL POSITION\n");
	}
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "averagey");
	ros::NodeHandle nh;

	ros::Subscriber subPointCloud = nh.subscribe("/particlecloud", 1000, &getCloud);
	ros::Subscriber subAMCLPoint = nh.subscribe("/amcl_pose", 1000, &amclGetPose);

	ros::spin();
	return 0;
}
